# ESP8266_Network_Clock
Use 7-Seg LED, 1602 LCD, 12864 display, LED Dot Matrix and ESP8266 NodeMCU to make a network clock  
Demo: https://www.bilibili.com/video/av50338779  

Recommend  
ESP8266：2.6.1  
Arduino IDE：1.8.10  
Arduino Time Library: https://github.com/PaulStoffregen/Time  
Arduino Timezone Library: https://github.com/JChristensen/Timezone  
网盘：http://t.cn/AisQmbyf 提取：27mx
